package Conexao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class ConexaoBancoDados {
    private static Connection conexao;

    public static Connection obterConexao() {
        if (conexao == null) {
            try {
                String url = "jdbc:mysql://localhost:3306/unicid?useSSL=false&characterEncoding=utf8";
                conexao = DriverManager.getConnection(url, "root", "");
            } catch (SQLException ex) {
                ex.printStackTrace();
            }
        }

        return conexao;
    }
}