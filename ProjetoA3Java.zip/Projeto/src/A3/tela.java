package A3;

import java.awt.EventQueue;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.DefaultComboBoxModel;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JRadioButton;
import javax.swing.JTabbedPane;
import javax.swing.JTextField;
import javax.swing.SwingConstants;
import javax.swing.border.EmptyBorder;
import Conexao.Validador;
import javax.swing.ButtonGroup;
import java.sql.PreparedStatement;
import java.sql.Connection;
import java.sql.DriverManager;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.sql.Connection;

public class tela extends JFrame {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private JPanel contentPane;
	private JTextField textField;
	public JTextField RA;
	public JTextField txtNome;
	public JTextField txtEndereco;
	public JPanel painelPeriodo;
	protected Object getUf;
    private JTextField textField_1;
    private JTextField textField_2;
    
    
    
    public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					tela frame = new tela();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	
	
	//código jradio
	
	
	
	
	public tela() throws Exception {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 760, 436);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		contentPane.setLayout(null);

		JTabbedPane tabbedPane = new JTabbedPane(JTabbedPane.TOP);
		tabbedPane.setBounds(10, 11, 727, 390);
		contentPane.add(tabbedPane);

		JPanel panel = new JPanel();
		tabbedPane.addTab("Dados Pessoais", null, panel, null);
		tabbedPane.setFont(new Font("Tahoma", Font.PLAIN, 15));
		
		panel.setLayout(null);

		JLabel lblNewLabel = new JLabel("RA:");
		lblNewLabel.setFont(new Font("Tahoma", Font.PLAIN, 20));
		lblNewLabel.setBounds(473, 76, 40, 38);
		panel.add(lblNewLabel);

		textField = new JTextField();
		textField.setBounds(86, 46, 113, -25);
		panel.add(textField);
		textField.setColumns(10);

		RA = new JTextField();
		RA.addKeyListener(new KeyAdapter() {
			@Override
			// definindo tipo de entrada no campo
			public void keyTyped(KeyEvent e) {
				String rgm = "0123456789";
				if (!rgm.contains(e.getKeyChar() + "")) {
					e.consume();
				}
			}
		});

		RA.setFont(new Font("Tahoma", Font.PLAIN, 20));
		RA.setBounds(518, 79, 182, 33);
		panel.add(RA);
		// uso do PlainDocument para limitir os campos
		RA.setDocument(new Validador(10));

		JLabel lblNewLabel_4 = new JLabel("Nome:");
		lblNewLabel_4.setFont(new Font("Tahoma", Font.PLAIN, 20));
		lblNewLabel_4.setBounds(8, 23, 73, 26);
		panel.add(lblNewLabel_4);

		txtNome = new JTextField();
		txtNome.addKeyListener(new KeyAdapter() {
			@Override
			// definindo tipo de entrada no campo
			public void keyTyped(KeyEvent e) {
				String caracteres = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ ";
				if (!caracteres.contains(e.getKeyChar() + "")) {
					e.consume();
				}
			}
		});

		txtNome.setFont(new Font("Tahoma", Font.PLAIN, 20));
		txtNome.setBounds(86, 18, 614, 38);
		panel.add(txtNome);
		// uso do PlainDocument para limitir os campos
		txtNome.setDocument(new Validador(60));

		JLabel lblNewLabel_5 = new JLabel("Sexo:");
		lblNewLabel_5.setFont(new Font("Tahoma", Font.PLAIN, 20));
		lblNewLabel_5.setBounds(8, 85, 58, 20);
		panel.add(lblNewLabel_5);

		JLabel lblNewLabel_7 = new JLabel("Livro:");
		lblNewLabel_7.setFont(new Font("Tahoma", Font.PLAIN, 20));
		lblNewLabel_7.setBounds(8, 134, 56, 33);
		panel.add(lblNewLabel_7);

		txtEndereco = new JTextField();
		txtEndereco.setFont(new Font("Tahoma", Font.PLAIN, 20));
		txtEndereco.setBounds(86, 241, 614, 32);
		panel.add(txtEndereco);
		// uso do PlainDocument para limitir os campos
		txtEndereco.setDocument(new Validador(60));
		
		JComboBox txtUf_1 = new JComboBox();
		txtUf_1.setFont(new Font("Tahoma", Font.PLAIN, 20));
		txtUf_1.setBounds(86, 79, 113, 33);
		panel.add(txtUf_1);
		
		JLabel lblNewLabel_4_1 = new JLabel("Idade:");
		lblNewLabel_4_1.setFont(new Font("Tahoma", Font.PLAIN, 20));
		lblNewLabel_4_1.setBounds(259, 82, 58, 26);
		panel.add(lblNewLabel_4_1);
		
		textField_1 = new JTextField();
		textField_1.setFont(new Font("Tahoma", Font.PLAIN, 20));
		textField_1.setBounds(327, 77, 103, 35);
		panel.add(textField_1);
		
		JComboBox txtUf_1_1 = new JComboBox();
		txtUf_1_1.setFont(new Font("Tahoma", Font.PLAIN, 20));
		txtUf_1_1.setBounds(86, 193, 131, 30);
		panel.add(txtUf_1_1);
		
		JLabel lblNewLabel_5_1 = new JLabel("Gênero:");
		lblNewLabel_5_1.setFont(new Font("Tahoma", Font.PLAIN, 20));
		lblNewLabel_5_1.setBounds(8, 198, 85, 20);
		panel.add(lblNewLabel_5_1);
		
		JLabel lblNewLabel_7_1 = new JLabel("Livro:");
		lblNewLabel_7_1.setFont(new Font("Tahoma", Font.PLAIN, 20));
		lblNewLabel_7_1.setBounds(10, 240, 56, 33);
		panel.add(lblNewLabel_7_1);
		
		JLabel lblNewLabel_5_1_1 = new JLabel("Gênero:");
		lblNewLabel_5_1_1.setFont(new Font("Tahoma", Font.PLAIN, 20));
		lblNewLabel_5_1_1.setBounds(10, 305, 73, 20);
		panel.add(lblNewLabel_5_1_1);
		
		JComboBox txtUf_1_1_1 = new JComboBox();
		txtUf_1_1_1.setFont(new Font("Tahoma", Font.PLAIN, 20));
		txtUf_1_1_1.setBounds(86, 302, 131, 33);
		panel.add(txtUf_1_1_1);
		
		JLabel lblNewLabel_5_1_2 = new JLabel("Nota:");
		lblNewLabel_5_1_2.setFont(new Font("Tahoma", Font.PLAIN, 20));
		lblNewLabel_5_1_2.setBounds(357, 198, 85, 20);
		panel.add(lblNewLabel_5_1_2);
		
		JLabel lblNewLabel_5_1_1_1 = new JLabel("Nota:");
		lblNewLabel_5_1_1_1.setFont(new Font("Tahoma", Font.PLAIN, 20));
		lblNewLabel_5_1_1_1.setBounds(357, 305, 73, 20);
		panel.add(lblNewLabel_5_1_1_1);
		
		JComboBox txtUf_1_1_2 = new JComboBox();
		txtUf_1_1_2.setFont(new Font("Tahoma", Font.PLAIN, 20));
		txtUf_1_1_2.setBounds(440, 193, 73, 30);
		panel.add(txtUf_1_1_2);
		
		JComboBox txtUf_1_1_2_1 = new JComboBox();
		txtUf_1_1_2_1.setFont(new Font("Tahoma", Font.PLAIN, 20));
		txtUf_1_1_2_1.setBounds(440, 300, 73, 30);
		panel.add(txtUf_1_1_2_1);
		
		textField_2 = new JTextField();
		textField_2.setFont(new Font("Tahoma", Font.PLAIN, 20));
		textField_2.setBounds(86, 135, 614, 32);
		panel.add(textField_2);
		tabbedPane.setFont(new Font("Tahoma", Font.PLAIN, 15));

		ButtonGroup buttonGroup = new ButtonGroup();
		tabbedPane.setFont(new Font("Tahoma", Font.PLAIN, 15));

		JPanel panel_3 = new JPanel();
		tabbedPane.addTab("Lista dos Livros", null, panel_3, null);
		
		JButton btnBoletim = new JButton("Lista dos Livros");
		panel_3.add(btnBoletim);
		tabbedPane.setFont(new Font("Tahoma", Font.PLAIN, 15));
        btnBoletim.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String rgm = JOptionPane.showInputDialog(null, "Digite o RA:");

                
               
                }                
        });
        
        
	}
}