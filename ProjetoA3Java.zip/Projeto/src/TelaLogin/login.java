package TelaLogin;

import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPasswordField;
import javax.swing.JTextField;
import javax.swing.SwingUtilities;


public class login extends JFrame {
    private JTextField usernameField;
    private JPasswordField passwordField;
    private JButton loginButton;

    public login() {
        setTitle("Sistema de Controle de Acesso");
        setSize(614, 81);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        getContentPane().setLayout(new FlowLayout());

        usernameField = new JTextField(15);

        getContentPane().add(new JLabel("Usuário: "));
        getContentPane().add(usernameField);
        JLabel label = new JLabel("Senha: ");
        getContentPane().add(label);
        passwordField = new JPasswordField(15);
        getContentPane().add(passwordField);
        loginButton = new JButton("Login");
        getContentPane().add(loginButton);
        
                loginButton.addActionListener(new ActionListener() {
                    @Override
                    public void actionPerformed(ActionEvent e) {
                        String username = usernameField.getText();
                        char[] passwordChars = passwordField.getPassword();
                        String password = new String(passwordChars);
        
                        if (autenticarUsuario(username, password)) {
                            JOptionPane.showMessageDialog(null, "Login bem-sucedido!");
                            // Implemente aqui a lógica para redirecionar o usuário para a interface apropriada.
                        } else {
                            JOptionPane.showMessageDialog(null, "Falha na autenticação!");
                        }
                    }
                });
    }

    private boolean autenticarUsuario(String username, String password) {
        Connection connection = null;

        try {
            // Configurar a conexão com o banco de dados MySQL (substitua com suas próprias credenciais)
            String url = "jdbc:mysql://localhost:3306/seubanco";
            String dbUser = "seuusuario";
            String dbPassword = "suasenha";

            connection = DriverManager.getConnection(url, dbUser, dbPassword);

            // Consulta para verificar as credenciais do usuário
            String query = "SELECT * FROM usuarios WHERE username = ? AND password = ?";
            PreparedStatement preparedStatement = connection.prepareStatement(query);
            preparedStatement.setString(1, username);
            preparedStatement.setString(2, password);

            ResultSet resultSet = preparedStatement.executeQuery();

            return resultSet.next(); // Se houver um resultado, o usuário foi autenticado com sucesso.
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        } finally {
            try {
                if (connection != null) {
                    connection.close();
                }
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(new Runnable() {
            public void run() {
                login sistema = new login();
                sistema.setVisible(true);
            }
        });
    }
}
